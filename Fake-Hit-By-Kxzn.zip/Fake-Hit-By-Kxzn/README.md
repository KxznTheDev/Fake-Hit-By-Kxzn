# This Was Made By Kxnz#1000

# How To Setup

Change The FakeHit.py To main.py(Replit Verison)

Change The "yourwebhook" To Your Webhook URL

Change The Username List(This Is Optional)

# Join Our Server For More
# https://discord.gg/2D2j95BZB7

# Warning ⚠

DO NOT SKID MY WORK